Integrantes: -Leticia Martínez Quintana
	     -Lucas Ávalos Torres

Para compilar: gcc parser.c -o parser 
		./parser fuente.txt

